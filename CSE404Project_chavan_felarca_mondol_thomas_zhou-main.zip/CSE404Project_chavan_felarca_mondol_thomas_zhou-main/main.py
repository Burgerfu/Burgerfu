import numpy as np
import sklearn
import matplotlib.pyplot as plt

if __name__ == '__main__':
    print("Hello team")
